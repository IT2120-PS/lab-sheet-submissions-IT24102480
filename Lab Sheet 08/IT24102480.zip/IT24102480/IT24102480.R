setwd("C:\\Users\\it24102480\\Desktop\\IT24102480")

data <- read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(data)
attach(data)


#Question 1
popmn <- mean(Weight.kg.) #Population mean
popvar <- var(Weight.kg.) * (length(Weight.kg.)-1)/length(Weight.kg.)
popSD <- sqrt(popvar)#Standered Deviation

popmn
popvar
popSD

#Question 2
samples <- c()
n <- c()

for (i in 1:25){
  s <- sample(Weight.kg., 6, replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n,paste('S',i))
}
colnames(samples) <- n
samples

s.means <- apply(samples, 2, mean) #Sample mean 
s.var   <- apply(samples, 2, var) #Sample Standered Deviation
s.SD    <- sqrt(s.var)

s.means
s.SD


#Question 3
mean_smeans <- mean(s.means)
sd_smeans   <- sd(s.means)


mean_smeans
sd_smeans

#True Mean and true Standered Deviation is not apromixaly equal